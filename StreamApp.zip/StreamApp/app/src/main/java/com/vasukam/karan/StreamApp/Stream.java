package com.vasukam.karan.StreamApp;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.VideoView;


public class Stream extends AppCompatActivity {

    VideoView VideoView;
    MediaController MC;
    ProgressBar PB;
    String URL= "file:///C:/Users/karan/Videos/Tom%20Clancy's%20Rainbow%20Six%20%20Siege/Tom%20Clancy's%20Rainbow%20Six%20%20Siege%202021.11.11%20-%2022.55.49.02.DVR.mp4";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stream);
        String search = getIntent().getStringExtra("searchParam");
        VideoView = findViewById(R.id.seeNow);
        PB=findViewById(R.id.progressBar);

        MC = new MediaController(this );
        MC.setAnchorView(VideoView);
        VideoView.setMediaController(MC);
        Uri uri = Uri.parse(URL);
        VideoView.setVideoURI(uri);
        VideoView.requestFocus();
            //simple request



        VideoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                VideoView.start();
                PB.setVisibility(View.GONE);
            }
        });
    }
}